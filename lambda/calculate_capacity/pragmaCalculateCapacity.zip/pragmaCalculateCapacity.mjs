import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";

function calculateMonthlyPayment(P, annualRate, months) {
    const i = annualRate / 12;
    if (i === 0) return P / months;
    return P * (i * Math.pow(1 + i, months)) / (Math.pow(1 + i, months) - 1);
}

const sqsClient = new SQSClient({ region: "us-east-1" });
const OUTPUT_QUEUE_URL = process.env.OUTPUT_QUEUE_URL;

export const handler = async (event) => {
    try {
        for (const record of event.Records) {
            const message = JSON.parse(record.body);
            const client = message.client;
            const approvedLoans = message.approvedLoanApplications;
            const newLoan = message.newLoanApplication;

            const baseSalary = parseFloat(client.baseSalary);
            const RISK_PERCENT = 0.35;
            const capacidadMax = baseSalary * RISK_PERCENT;

            let deudaMensualActual = 0;
            for (const loan of approvedLoans) {
                const cuota = calculateMonthlyPayment(
                    parseFloat(loan.amount),
                    parseFloat(loan.interestRate || 0),
                    loan.term
                );
                deudaMensualActual += cuota;
            }

            const capacidadDisponible = Math.max(capacidadMax - deudaMensualActual, 0);
            const cuotaNuevo = calculateMonthlyPayment(
                parseFloat(newLoan.amount),
                parseFloat(newLoan.interestRate || 0),
                newLoan.term
            );

            const decision = cuotaNuevo <= capacidadDisponible ? "Aprobada" : "Rechazada";

            const outputMessage = {
                response:{
                    loanApplicationId: newLoan.idLoanApplication,
                    status: decision
                }
            };

            await sqsClient.send(new SendMessageCommand({
                QueueUrl: OUTPUT_QUEUE_URL,
                MessageBody: JSON.stringify(outputMessage)
            }));

            console.log(`LoanApplication ${newLoan.idLoanApplication} decision "${decision}" enviado a la SQS`);
        }

        return { statusCode: 200, body: "Success" };

    } catch (error) {
        console.error("Error in calculate capacity Lambda", error);
        return { statusCode: 500, body: "Internal Server Error" };
    }
};