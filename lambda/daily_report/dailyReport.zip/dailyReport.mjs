import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { SESClient, SendTemplatedEmailCommand } from "@aws-sdk/client-ses";

const dynamo = new DynamoDBClient({ region: "us-east-1" });
const ses = new SESClient({ region: "us-east-1" });
const TEMPLATE_NAME = process.env.TEMPLATE_NAME || "ReporteDiarioSolicitudes";

export const handler = async () => {
  try {
    const now = new Date();
    const today = now.toISOString().split("T")[0];

    const result = await dynamo.send(
      new ScanCommand({
        TableName: "Reports",
      })
    );

    const reports = result.Items.filter((item) => {
      if (!item.updatedAt || !item.updatedAt.N) return false;

      const updatedAt = new Date(Number(item.updatedAt.N));

      return (
        updatedAt.toISOString().split("T")[0] === today &&
        updatedAt <= now
      );
});


    if (reports.length === 0) {
      console.log("No hay reportes hasta ahora:", now.toISOString());
      return;
    }

    let approvedCount = 0;
    let rejectedCount = 0;
    let moneySum = 0;
    let totalCount = 0;

    for (const r of reports) {
      const status = r.status.S;
      const total = parseInt(r.total.N);
      const amount = r.amount ? parseFloat(r.amount.N) : 0;

      if (status === "Aprobada") {
        approvedCount += total;
        moneySum += amount;
      } else if (status === "Rechazada") {
        rejectedCount += total;
      }
      totalCount += total;
    }

    const params = {
      Source: "sagasteguiherradaa@gmail.com",
      Destination: {
        ToAddresses: ["allxn.sxh@gmail.com"],
      },
      Template: TEMPLATE_NAME,
      TemplateData: JSON.stringify({
        reportDate: now.toLocaleString("es-PE", { timeZone: "America/Lima" }),
        approvedCount,
        rejectedCount,
        moneySum: moneySum.toFixed(2),
        totalCount,
      }),
    };

    await ses.send(new SendTemplatedEmailCommand(params));
    console.log("Reporte enviado al admin:", now.toISOString());

  } catch (err) {
    console.error("Error enviando reporte:", err);
    throw err;
  }
};