import { SESClient, SendTemplatedEmailCommand } from "@aws-sdk/client-ses";

const sesClient = new SESClient({ region: "us-east-1" });
const TEMPLATE_NAME = process.env.TEMPLATE_NAME || "PragmaLoanStatusTemplate";

function calculateMonthlyPayment(P, annualRate, months) {
  const i = (annualRate/100) / 12;
  if (i === 0) return P / months;
  return P * (i * Math.pow(1 + i, months)) / (Math.pow(1 + i, months) - 1);
}

function generatePaymentPlan(P, annualRate, months) {
  const monthlyRate = (annualRate/100) / 12;
  const cuota = calculateMonthlyPayment(P, annualRate, months);

  let balance = P;
  const plan = [];

  for (let month = 1; month <= months; month++) {
    const interest = balance * monthlyRate;
    const principal = cuota - interest;
    balance -= principal;

    plan.push({
      month,
      cuota: cuota.toFixed(2),
      principal: principal.toFixed(2),
      interest: interest.toFixed(2),
      balance: balance > 0 ? balance.toFixed(2) : "0.00",
    });
  }

  return plan;
}

export const handler = async (event) => {
  for (const record of event.Records) {
    const message = JSON.parse(record.Sns.Message);

    const loanApp = message.loanApplicationData || {};
    const client = message.clientSnapshot || {};

    const idLoanApplication = loanApp.idLoanApplication || "N/A";
    const status = loanApp.status || "Desconocido";
    const amount = parseFloat(loanApp.amount) || 0;
    const term = parseInt(loanApp.term) || 0;
    const loanType = loanApp.loanType || "General";

    const name = client.name || "Cliente";
    const lastName = client.lastName || "";
    const email = client.email || "sin-correo";

    const interestRate = parseFloat(message.interestRate) || 0;

    let statusColor = "#ded44dff";
    if (status.toLowerCase() === "aprobada") {
      statusColor = "#28a745";
    } else if (status.toLowerCase() === "rechazada") {
      statusColor = "#dc3545";
    }

    let paymentPlan = [];
    if (status.toLowerCase() === "aprobada") {
      paymentPlan = generatePaymentPlan(amount, interestRate, term);
    }

    try {
      const command = new SendTemplatedEmailCommand({
        Source: "sagasteguiherradaa@gmail.com",
        Destination: {
          ToAddresses: [email],
        },
        Template: TEMPLATE_NAME,
        TemplateData: JSON.stringify({
          idLoanApplication,
          status,
          amount,
          term,
          loanType,
          name,
          lastName,
          statusColor,
          paymentPlan,
          showPlan: status.toLowerCase() === "aprobada"
        }),
      });

      const response = await sesClient.send(command);
      console.log(`Correo enviado a ${email}, MessageId: ${response.MessageId}`);
    } catch (err) {
      console.error(`Error al enviar correo a ${email}:`, err);
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify("Correos procesados con SES Template"),
  };
};