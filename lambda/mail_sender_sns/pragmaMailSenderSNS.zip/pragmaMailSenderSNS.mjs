import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";

const snsClient = new SNSClient({ region: "us-east-1" });
const TOPIC_ARN = process.env.TOPIC_ARN;

export const handler = async (event) => {
  for (const record of event.Records) {
    const body = JSON.parse(record.body);

    const payload = {
      loanApplicationData: body.loanApplicationData || {},
      clientSnapshot: body.clientSnapshot || {},
      interestRate: body.interestRate || 0,
      totalMonthlyDebt: body.totalMonthlyDebt || 0,
      approvedLoans: body.approvedLoans || 0,
    };

    try {
      const command = new PublishCommand({
        TopicArn: TOPIC_ARN,
        Subject: "Resultado de tu solicitud de crédito",
        Message: JSON.stringify(payload),
      });

      const response = await snsClient.send(command);
      console.log(`Evento publicado en SNS, MessageId: ${response.MessageId}`);
    } catch (err) {
      console.error("Error al publicar en SNS:", err);
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify("Eventos enviados a SNS"),
  };
};